const card = [
  {
    name: "IT",
    img: "/img/it.jpg",
  },
  {
    name: "Engineering",
    img: "/img/Engineering.jpg",
  },
  {
    name: "Pharma",
    img: "/img/Pharma.jpg",
  },
  {
    name: "HealthCare",
    img: "/img/Healthcare.jpg",
  },
  {
    name: "Hospitality",
    img: "/img/Hospitality.jpg",
  },
  {
    name: "Finance & Accounts",
    img: "/img/Finance and Accounting.jpeg",
  },
  {
    name: "Administration",
    img: "/img/administration.jpg",
  },
  {
    name: "Manufacturing",
    img: "/img/manufacturing.jpeg",
  },
  {
    name: "Robotics",
    img: "/img/robotics.jpg",
  },
  {
    name: "Advertising",
    img: "/img/advertising.jpg",
  },
  {
    name: "Aerospace",
    img: "/img/Aerospace.jpg",
  },
  {
    name: "Architect",
    img: "/img/architect.jpg",
  },
  {
    name: "Aviation",
    img: "/img/Aviation.jpg",
  },
  {
    name: "Airlines",
    img: "/img/Airlines.jpg",
  },
  {
    name: "Battery",
    img: "/img/Battery.jpeg",
  },
  {
    name: "Biomedical",
    img: "/img/biomedical.jpg",
  },
  {
    name: "Chemicals",
    img: "/img/chemicals.jpg",
  },
  {
    name: "Construction & Industrial",
    img: "/img/construction and Industrial.png",
  },
  {
    name: "Corporate",
    img: "/img/corporate.jpg",
  },
  {
    name: "Customer Service",
    img: "/img/customer service.jpg",
  },
  {
    name: "Cyber Security",
    img: "/img/cyber security.jpg",
  },
  {
    name: "E-commerce",
    img: "/img/e-commerce.jpg",
  },
  {
    name: "education",
    img: "/img/education.jpg",
  },
  // {
  //     name: "industrial",
  //     img: "/img/Industrial.jpg"
  // },

  {
    name: "Legal",
    img: "/img/Legal.png",
  },

  {
    name: "Marketing",
    img: "/img/marketing.jpg",
  },
  {
    name: "Oil and Gas Industry",
    img: "/img/Oil and Gas Industry.jpg",
  },

  {
    name: "Real Estate",
    img: "/img/real estate.jpg",
  },
  {
    name: "Retail",
    img: "/img/retail.jpg",
  },

  {
    name: "Sales",
    img: "/img/sales.jpg",
  },
  {
    name: "Scientific",
    img: "/img/scientific.jpg",
  },
  {
    name: "TeleCom",
    img: "/img/Telecom.png",
  },
  {
    name: "Transportation",
    img: "/img/transportation.jpg",
  },
];
export default card;
